//
//  TemViewController.h
//  pro1
//
//  Created by ByteDance on 2022/8/4.
//

#import <UIKit/UIKit.h>
#import "WeatherReportView.h"

NS_ASSUME_NONNULL_BEGIN

@interface TemViewController : UIViewController

@property (nonatomic, strong) WeatherReportView* weatherReportView;


@end

NS_ASSUME_NONNULL_END
