//
//  ViewController2.h
//  pro1
//
//  Created by ByteDance on 2022/6/24.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ViewController2 : UIViewController

@end

NS_ASSUME_NONNULL_END
